package com.example.dsl.springintegration.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Request {
	
	public String empName;
	public int empId;
	public String orgDetailsLink;
	public String personalDetailsLink;
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getOrgDetailsLink() {
		return orgDetailsLink;
	}
	public void setOrgDetailsLink(String orgDetailsLink) {
		this.orgDetailsLink = orgDetailsLink;
	}
	public String getPersonalDetailsLink() {
		return personalDetailsLink;
	}
	public void setPersonalDetailsLink(String personalDetailsLink) {
		this.personalDetailsLink = personalDetailsLink;
	}
	
	@Override
	public String toString() {
		String student = null;
		try {
			student = new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return student;
	}
	
	
}
