package com.example.dsl.springintegration.util;

import java.util.List;

import org.springframework.integration.store.SimpleMessageStore;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import com.example.dsl.springintegration.domain.EmployeeDetails;
import com.example.dsl.springintegration.domain.EmploymentDetails;
import com.example.dsl.springintegration.domain.OrgDetails;
import com.example.dsl.springintegration.domain.PersonalInfoDetails;
import com.example.dsl.springintegration.model.Request;
import com.example.dsl.springintegration.model.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public interface ApplicationUtil {
	
	public static final String INPUT_REQUEST = "inputRequest";
	public static final String MY_RESPONSE_PAYLOAD = "myResponsePayload";
	
	public static Response populatePersonalInfoDetails(Message<String> msg, ObjectMapper objectMapper, SimpleMessageStore messageStore)
			throws JsonProcessingException, JsonMappingException {
		Message<?> respMsgPayload =  (Message<?>) MessageUtil.getMsgFromGroup(messageStore, MY_RESPONSE_PAYLOAD);
		((Response)respMsgPayload.getPayload()).getEmployeeDetails()
											   .setPersonalInfoDetails(objectMapper.readValue
													   				  (msg.getPayload(), PersonalInfoDetails.class));
		MessageUtil.addMsgToGroup(messageStore, respMsgPayload, MY_RESPONSE_PAYLOAD);
		return (Response)respMsgPayload.getPayload();
	}

	public static Response populateTrustScore(Message<String> msg, SimpleMessageStore messageStore) {
		Message<?> respMsgPayload =  (Message<?>) MessageUtil.getMsgFromGroup(messageStore, MY_RESPONSE_PAYLOAD);
		List<OrgDetails> prevOrgDetailsStored = ((Response)respMsgPayload.getPayload()).getEmployeeDetails().getEmploymentDetails().getPrevOrgDetails();
		String[] scoreDetails = msg.getPayload().replace("[", "").replace("]", "").split(",");
		int scoreIndex = 0;
		int totalScore = 0;
		for(String score : scoreDetails) {
			prevOrgDetailsStored.get(scoreIndex).setTrustScore(Integer.valueOf(score.trim()));
			totalScore = totalScore + Integer.valueOf(score.trim());
			scoreIndex++ ;
		}
		((Response)respMsgPayload.getPayload()).getEmployeeDetails().getEmploymentDetails().setTotalTrustScore(totalScore);
		MessageUtil.addMsgToGroup(messageStore, respMsgPayload, MY_RESPONSE_PAYLOAD);
		return (Response)respMsgPayload.getPayload();
	}

	public static Response populateEmployeeDetails(Message<String> msg, ObjectMapper objectMapper, SimpleMessageStore messageStore) {
		EmployeeDetails employeeDetails = new EmployeeDetails();
		Message<?> respMsgPayload =  (Message<?>) MessageUtil.getMsgFromGroup(messageStore, INPUT_REQUEST);
		Request request = (Request)respMsgPayload.getPayload();
		try {
			employeeDetails.setEmploymentDetails(objectMapper.readValue(msg.getPayload(), EmploymentDetails.class));
		}catch (Exception e) {
			System.out.println(e);
		}
		employeeDetails.setName(request.getEmpName());
		employeeDetails.setId(request.getEmpId());
		Response response = new Response();
		response.setEmployeeDetails(employeeDetails);
		Message<?> respMessage = MessageBuilder.withPayload(response).build();
		MessageUtil.addMsgToGroup(messageStore, respMessage, MY_RESPONSE_PAYLOAD);
		return response;
	}

}
