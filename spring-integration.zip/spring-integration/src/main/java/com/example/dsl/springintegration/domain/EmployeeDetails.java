package com.example.dsl.springintegration.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeDetails {
	
	public String name;
	public int id;
	public EmploymentDetails employmentDetails;
	public PersonalInfoDetails personalInfoDetails;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public EmploymentDetails getEmploymentDetails() {
		return employmentDetails;
	}
	public void setEmploymentDetails(EmploymentDetails employmentDetails) {
		this.employmentDetails = employmentDetails;
	}
	public PersonalInfoDetails getPersonalInfoDetails() {
		return personalInfoDetails;
	}
	public void setPersonalInfoDetails(PersonalInfoDetails personalInfoDetails) {
		this.personalInfoDetails = personalInfoDetails;
	}
	
	@Override
	public String toString() {
		String student = null;
		try {
			student = new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return student;
	}


}
