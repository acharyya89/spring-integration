package com.example.dsl.springintegration.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.integration.store.SimpleMessageStore;
import org.springframework.messaging.Message;

public class MessageUtil {
	
	public static void removeMsgToGroup(SimpleMessageStore messageStore, String groupId) {
		messageStore.removeMessageGroup(groupId);
	}
	
	public static void addMsgToGroup(SimpleMessageStore messageStore, Message<?> respMessage, String groupId) {
		messageStore. addMessagesToGroup(groupId, respMessage);
	}
	
	public static Message<?> getMsgFromGroup(SimpleMessageStore messageStore, String groupId) {
		Collection<Message<?>> messages = null;
		try {
			 messages = messageStore.getMessagesForGroup(groupId);
			 List<Message<?>> responseMessages = new ArrayList<>(messages);
			return responseMessages.get(0);
		}catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
