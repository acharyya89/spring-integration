package com.example.dsl.springintegration.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.stereotype.Component;

@Component
public class ErrorHandler {
	
	public static ResponseEntity<ApplicationException> handleError(ErrorMessage errorMessage){
		
		System.out.println("ERROR HANDLER HANDLING ERROR MESSAGE "+ errorMessage);
		ApplicationException exception = new ApplicationException();
		exception.setMsg("Following exception has occured. Please contact system adminstrator");
		exception.setExceptionDetails(errorMessage.getPayload().getMessage());
		return new ResponseEntity<ApplicationException>(exception, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
