package com.example.dsl.springintegration.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.ErrorMessage;

import com.example.dsl.springintegration.exception.ApplicationException;
import com.example.dsl.springintegration.exception.ErrorHandler;
import com.example.dsl.springintegration.model.Request;

@Configuration
public class EmployeeConfiguration {
	
	@Bean
	public IntegrationFlow httpPostPutFlow() {
	    return IntegrationFlows.from(Http.inboundGateway("/customerservice2/testget1")
	    		.errorChannel("errorChannel"))
	    		.channel("routeRequest")
	    		.route("headers.http_requestMethod", 
	    				m -> m.prefix("http").suffix("Channel")
	    				.channelMapping("PUT", "Put")
	    				.channelMapping("POST", "Post")
	    				.channelMapping("GET", "Get")
	    			   )
	    		.get();
	}
	
	@Bean
	public IntegrationFlow subscribersFlow() {
		return IntegrationFlows
	    		.from("httpPostChannel")
	    		.transform(Transformers.fromJson(Request.class))
	    		.enrich(e -> e.requestChannel("enrichChannel")
	    				.requestPayload(Message::getPayload)
	    				.shouldClonePayload(false))
	    		.routeToRecipients(input -> input
	    				.recipient("employmentDetailsChannel")
	    				.recipient("personalInfoDetailsChannel")
	    				.defaultOutputChannel("errorCheckChannel")
	    				)
	            .get();
	}
	
    @ServiceActivator(inputChannel="errorChannel") 
    public ResponseEntity<ApplicationException> onError(ErrorMessage message) {
    	return ErrorHandler.handleError(message);
    }
    
}
