package com.example.dsl.springintegration.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.store.SimpleMessageStore;
import org.springframework.messaging.Message;

import com.example.dsl.springintegration.model.Request;

@Configuration
public class MessageConfiguration {
	
	@Bean
	public SimpleMessageStore messageStore() {
		return new SimpleMessageStore();
	}
	
    @ServiceActivator(inputChannel = "enrichChannel")
    public Message<Request> storeInputMessage(Message<Request> request) {
        messageStore().addMessagesToGroup("inputRequest", request);
        return request;
    }
    
}
