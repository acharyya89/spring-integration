package com.example.dsl.springintegration.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.http.dsl.Http;

import com.example.dsl.springintegration.model.Request;
import com.example.dsl.springintegration.service.UserService;

@Configuration
public class PersonalInfoDetailsSubConfiguration {
	
	@Autowired
	UserService userService;
	
	@Bean
	public IntegrationFlow fetchPersonalInfoChannelFlow() {
		return IntegrationFlows
	    		.from("personalInfoDetailsChannel")
	    		.handle(Http.outboundGateway(m -> ((Request)m.getPayload()).getPersonalDetailsLink())
			            .httpMethod(HttpMethod.GET)
			            .expectedResponseType(String.class)
			            .get())
	    		.enrichHeaders(h -> h.header("isEmploymentDetails", "false"))
	    		.handle("userService", "addEmploymentDetails")
	            .get();
	}
	
}
