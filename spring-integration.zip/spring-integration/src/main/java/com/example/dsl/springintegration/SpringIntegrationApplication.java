package com.example.dsl.springintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.integration.config.EnableIntegration;

import com.fasterxml.jackson.core.JsonProcessingException;

@SpringBootApplication
@EnableIntegration
public class SpringIntegrationApplication {

	public static void main(String[] args) throws JsonProcessingException {
		SpringApplication.run(SpringIntegrationApplication.class, args);
	}

}
