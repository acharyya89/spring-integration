package com.example.dsl.springintegration.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OrgDetails {
	
	String orgName;
	String orgEmpId;
	int pfAmount;
	int trustScore;
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getOrgEmpId() {
		return orgEmpId;
	}
	public void setOrgEmpId(String orgEmpId) {
		this.orgEmpId = orgEmpId;
	}
	public int getPfAmount() {
		return pfAmount;
	}
	public void setPfAmount(int pfAmount) {
		this.pfAmount = pfAmount;
	}
	public int getTrustScore() {
		return trustScore;
	}
	public void setTrustScore(int trustScore) {
		this.trustScore = trustScore;
	}
	
	@Override
	public String toString() {
		String student = null;
		try {
			student = new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return student;
	}

}
