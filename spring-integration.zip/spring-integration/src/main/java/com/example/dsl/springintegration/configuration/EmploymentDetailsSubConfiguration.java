package com.example.dsl.springintegration.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.http.dsl.Http;

import com.example.dsl.springintegration.domain.OrgDetails;
import com.example.dsl.springintegration.model.Request;
import com.example.dsl.springintegration.model.Response;
import com.example.dsl.springintegration.service.UserService;

@Configuration
public class EmploymentDetailsSubConfiguration {
	
	@Value("${integration.employee.trust.score}")
	String trustScoreLink;
	
	@Autowired
	UserService userService;
	
	@Bean
	public IntegrationFlow fetchEmploymentDetailsFlow() {
		return IntegrationFlows
	    		.from("employmentDetailsChannel")
	    		.handle(Http.outboundGateway(m -> ((Request)m.getPayload()).getOrgDetailsLink())
			            .httpMethod(HttpMethod.GET)
			            .expectedResponseType(String.class)
			            .get()
	    				)
	    		.enrichHeaders(h -> h.header("isEmploymentDetails", "true"))
	    		.handle("userService", "addEmploymentDetails")
	    		.<Response>split(Response.class, (resp) -> resp
										    			  .getEmployeeDetails()
										    			  .getEmploymentDetails()
										    			  .getPrevOrgDetails())
	    		.handle(Http.outboundGateway(orgNames -> {return trustScoreLink 
										    			   		+ ((OrgDetails) orgNames
								    					          .getPayload())
								    			                  .getOrgName().toLowerCase();})
			            .httpMethod(HttpMethod.GET)
			            .expectedResponseType(String.class)
			            .get())
	    		.aggregate()
	    		.enrichHeaders(h -> h.header("calculateTrustScore", "true"))
	    		.handle("userService", "addEmploymentDetails")
	            .get();
	}
	
}
