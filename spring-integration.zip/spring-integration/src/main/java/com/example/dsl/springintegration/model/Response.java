package com.example.dsl.springintegration.model;

import com.example.dsl.springintegration.domain.EmployeeDetails;

public class Response {
	
	public String respMsg;
	public String status;
	public EmployeeDetails employeeDetails;
	
	public String getRespMsg() {
		return respMsg;
	}
	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public EmployeeDetails getEmployeeDetails() {
		return employeeDetails;
	}
	public void setEmployeeDetails(EmployeeDetails employeeDetails) {
		this.employeeDetails = employeeDetails;
	}

}
