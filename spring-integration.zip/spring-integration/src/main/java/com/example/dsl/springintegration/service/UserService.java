package com.example.dsl.springintegration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.store.SimpleMessageStore;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.example.dsl.springintegration.model.Response;
import com.example.dsl.springintegration.util.ApplicationUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class UserService {

	@Autowired
	SimpleMessageStore messageStore;

	public Response addEmploymentDetails(Message<String> msg) throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		if ("true".equals(msg.getHeaders().get("isEmploymentDetails"))
				&& !"true".equals(msg.getHeaders().get("calculateTrustScore"))) {
			return ApplicationUtil.populateEmployeeDetails(msg, objectMapper, messageStore);
		} else if ("true".equals(msg.getHeaders().get("calculateTrustScore"))) {
			return ApplicationUtil.populateTrustScore(msg, messageStore);
		} else if ("false".equals(msg.getHeaders().get("isEmploymentDetails"))) {
			return ApplicationUtil.populatePersonalInfoDetails(msg, objectMapper, messageStore);
		}
		return null;
	}

}
